// ...dentro del formulario de avance
<label>Usuario:</label><br>
<input type="text" name="usuario" value="<?= esc(session('usuario_nombre')) ?>" readonly>