    </main>
    <footer>
        <hr>
        <small>&copy; <?= date('Y') ?> Servicio Nacional de Patrimonio del Estado – SENAPE</small>
    </footer>
</body>
</html>