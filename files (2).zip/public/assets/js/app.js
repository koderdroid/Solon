// JS personalizado para SNP insights
$(document).ready(function() {
    // Aquí puedes agregar JS para validaciones o interactividad extra
    // DataTables para tablas
    if (typeof $.fn.DataTable !== "undefined") {
        $('.display').DataTable();
    }
});