Direcciones y unidades cubiertas:
- DRP: Dirección de Registro y Promoción
- DBRAE: Dirección de Disposición de Bienes y Recuperación de Activos Exigibles
- DLEGSS: Dirección de Liquidación de ex Entes Gestores de la Seguridad Social
- DAF: Dirección Administrativa y Financiera
- DJ: Dirección Jurídica
- OD: Oficinas Distritales (Oruro, Cochabamba, Santa Cruz, Chuquisaca, Beni)
- UAI: Unidad de Auditoría Interna
- TRA: Área de Transparencia

Niveles de usuario previstos:
- Administrador
- Planificador
- Ejecutor
- Evaluador/Gerente